from django.contrib.auth import authenticate
from django.contrib.auth.tokens import default_token_generator
from django.utils.encoding import force_bytes, force_str
from django.utils.http import urlsafe_base64_decode, urlsafe_base64_encode
from rest_framework import serializers
from rest_framework_simplejwt.tokens import RefreshToken

from .models import User


class UserSerializer(serializers.ModelSerializer):
    """Read-only user profile shape, per claude/API_CONTRACT.md."""

    class Meta:
        model = User
        fields = ["user_id", "email", "first_name", "last_name", "role", "course", "created_at"]
        read_only_fields = fields


def _tokens_for_user(user):
    refresh = RefreshToken.for_user(user)
    return {"access": str(refresh.access_token), "refresh": str(refresh)}


class RegisterSerializer(serializers.ModelSerializer):
    """
    POST /api/v1/auth/register/ - public, student accounts only.
    Admin accounts are created manually via `manage.py createsuperuser`.
    """

    password = serializers.CharField(write_only=True, min_length=8)
    course = serializers.ChoiceField(choices=User.Course.choices)

    class Meta:
        model = User
        fields = ["email", "password", "first_name", "last_name", "course"]

    def validate_email(self, value):
        value = value.lower().strip()
        if User.objects.filter(email__iexact=value).exists():
            raise serializers.ValidationError("An account with this email already exists.")
        return value

    def create(self, validated_data):
        validated_data["role"] = User.Role.STUDENT
        password = validated_data.pop("password")
        user = User(**validated_data)
        user.set_password(password)
        user.save()
        return user

    def to_representation(self, instance):
        return {"user": UserSerializer(instance).data, **_tokens_for_user(instance)}


class LoginSerializer(serializers.Serializer):
    """POST /api/v1/auth/login/ - public. Same response shape as register."""

    email = serializers.EmailField()
    password = serializers.CharField(write_only=True)

    def validate(self, attrs):
        user = authenticate(
            request=self.context.get("request"),
            username=attrs["email"].lower().strip(),
            password=attrs["password"],
        )
        if user is None:
            raise serializers.ValidationError("Invalid email or password.")
        if not user.is_active:
            raise serializers.ValidationError("This account has been deactivated.")
        attrs["user"] = user
        return attrs

    def to_representation(self, instance):
        user = instance["user"]
        return {"user": UserSerializer(user).data, **_tokens_for_user(user)}


class PasswordResetRequestSerializer(serializers.Serializer):
    """
    POST /api/v1/auth/password-reset/ - public.
    Always succeeds regardless of whether the email exists, to avoid leaking
    which emails are registered (email enumeration).
    """

    email = serializers.EmailField()

    def save(self, **kwargs):
        email = self.validated_data["email"].lower().strip()
        try:
            user = User.objects.get(email__iexact=email)
        except User.DoesNotExist:
            return None

        uid = urlsafe_base64_encode(force_bytes(user.pk))
        token = default_token_generator.make_token(user)
        return {"user": user, "uid": uid, "token": token}


class PasswordResetConfirmSerializer(serializers.Serializer):
    """POST /api/v1/auth/password-reset/confirm/ - public."""

    uid = serializers.CharField()
    token = serializers.CharField()
    new_password = serializers.CharField(write_only=True, min_length=8)

    def validate(self, attrs):
        try:
            user_id = force_str(urlsafe_base64_decode(attrs["uid"]))
            user = User.objects.get(pk=user_id)
        except (TypeError, ValueError, OverflowError, User.DoesNotExist):
            raise serializers.ValidationError("This reset link is invalid or has expired.")

        if not default_token_generator.check_token(user, attrs["token"]):
            raise serializers.ValidationError("This reset link is invalid or has expired.")

        attrs["user"] = user
        return attrs

    def save(self, **kwargs):
        user = self.validated_data["user"]
        user.set_password(self.validated_data["new_password"])
        user.save()
        return user
