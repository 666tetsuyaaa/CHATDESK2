## Password Reset

Two-step flow: request a reset (always returns success regardless of whether
the email exists, to prevent attackers from probing which emails are
registered), then confirm with the token from the email.

### POST /api/v1/auth/password-reset/
Public.

Request:
{
  "email": "student@gmail.com"
}
Response 200 (always, whether or not the email exists):
{
  "message": "If an account exists with that email, a reset link has been sent."
}

### POST /api/v1/auth/password-reset/confirm/
Public.

Request:
{
  "uid": "encoded_user_id_string",
  "token": "reset_token_string",
  "new_password": "newSecurePassword123"
}
Response 200:
{
  "message": "Password has been reset successfully."
}
Response 400 (invalid/expired token, or password fails validation):
{
  "error": "validation_error",
  "message": "This reset link is invalid or has expired.",
  "details": {}
}

Note: the reset email contains a link to a frontend page (web:
{FRONTEND_PASSWORD_RESET_URL}?uid=...&token=...) which collects the new
password and calls the confirm endpoint above. Mobile needs an equivalent
deep link scheme - tracked separately with Keith, not blocking this contract.
